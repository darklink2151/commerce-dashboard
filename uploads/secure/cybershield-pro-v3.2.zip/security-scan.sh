#!/bin/bash
#
# CyberShield Pro Security Suite - Basic Security Scanner
# This script performs basic security checks on a Linux system
#

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m' # No Color

echo -e "${BLUE}${BOLD}CyberShield Pro Security Suite - Basic Security Scanner${NC}"
echo -e "${BLUE}======================================================${NC}"
echo

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${YELLOW}[WARNING] This script should be run as root for full functionality${NC}"
   echo
fi

# Function to print section headers
section() {
    echo -e "${BOLD}$1${NC}"
    echo -e "${BLUE}$(printf '=%.0s' {1..50})${NC}"
}

# Function to check result and print status
check_result() {
    if [ $1 -eq 0 ]; then
        echo -e "[${GREEN}PASS${NC}] $2"
    else
        echo -e "[${RED}FAIL${NC}] $2"
    fi
}

# System Information
section "System Information"
echo "Hostname: $(hostname)"
echo "Kernel: $(uname -r)"
echo "OS: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')"
echo "IP Address: $(hostname -I | awk '{print $1}')"
echo

# Check for updates
section "System Updates"
if command -v apt-get &> /dev/null; then
    updates=$(apt-get -s upgrade | grep -P '^\d+ upgraded' | cut -d" " -f1)
    security_updates=$(apt-get -s upgrade | grep -c security)
    echo -e "Available updates: ${YELLOW}$updates${NC}"
    echo -e "Security updates: ${YELLOW}$security_updates${NC}"
elif command -v yum &> /dev/null; then
    updates=$(yum check-update --quiet | grep -v "^$" | wc -l)
    echo -e "Available updates: ${YELLOW}$updates${NC}"
fi
echo

# Check for open ports
section "Network Security"
echo "Open ports and listening services:"
netstat -tuln 2>/dev/null || ss -tuln 2>/dev/null || echo "No tool available to check ports"
echo

# Check for common security issues
section "Security Checks"

# Check SSH configuration
if [ -f /etc/ssh/sshd_config ]; then
    echo "SSH Configuration:"
    
    # Check if password authentication is disabled
    grep -q "^PasswordAuthentication no" /etc/ssh/sshd_config
    check_result $? "Password authentication disabled"
    
    # Check if root login is disabled
    grep -q "^PermitRootLogin no" /etc/ssh/sshd_config
    check_result $? "Root login disabled"
    
    # Check for strong SSH protocol
    grep -q "^Protocol 2" /etc/ssh/sshd_config
    check_result $? "Using SSH Protocol 2"
else
    echo -e "${YELLOW}[INFO] SSH server not installed${NC}"
fi
echo

# Check firewall status
echo "Firewall Status:"
if command -v ufw &> /dev/null; then
    ufw status | grep -q "Status: active"
    check_result $? "UFW firewall active"
elif command -v firewalld &> /dev/null; then
    firewall-cmd --state | grep -q "running"
    check_result $? "FirewallD active"
elif command -v iptables &> /dev/null; then
    iptables -L | grep -q "Chain INPUT"
    check_result $? "IPTables has rules configured"
else
    echo -e "${RED}[FAIL] No firewall detected${NC}"
fi
echo

# Check for suspicious processes
section "Process Analysis"
echo "Top CPU processes:"
ps aux --sort=-%cpu | head -n 6
echo
echo "Checking for suspicious processes..."
# This is a simplified check - the full version would have more comprehensive detection
ps aux | grep -E "nc -l|netcat -l|ncat -l|miner|cryptominer" | grep -v grep
if [ $? -ne 0 ]; then
    echo -e "${GREEN}[PASS] No common suspicious processes detected${NC}"
else
    echo -e "${RED}[WARNING] Potentially suspicious processes found${NC}"
fi
echo

# Check for common rootkits
section "Rootkit Detection"
if command -v rkhunter &> /dev/null; then
    echo "RKHunter is installed. Run 'rkhunter --check' for a full scan."
elif command -v chkrootkit &> /dev/null; then
    echo "Chkrootkit is installed. Run 'chkrootkit' for a full scan."
else
    echo -e "${YELLOW}[WARNING] No rootkit detection tools installed${NC}"
    echo "Consider installing rkhunter or chkrootkit"
fi
echo

# Check user accounts
section "User Account Security"
echo "Users with UID 0 (root access):"
grep "x:0:" /etc/passwd
echo
echo "Users with login shell:"
grep -v "/nologin\|/false" /etc/passwd
echo
echo "Recently created users:"
ls -la /home
echo

# Check for world-writable files
section "File Permissions"
echo "Checking for world-writable files in /etc (can be dangerous)..."
find /etc -type f -perm -o+w -exec ls -l {} \; 2>/dev/null
if [ $? -ne 0 ]; then
    echo -e "${GREEN}[PASS] No world-writable files found in /etc${NC}"
fi
echo

# Summary
section "Security Scan Summary"
echo -e "${YELLOW}This is a basic security scan. For a comprehensive assessment:${NC}"
echo -e "1. Update all packages: ${BOLD}apt update && apt upgrade${NC} or ${BOLD}yum update${NC}"
echo -e "2. Install and configure a firewall if not active"
echo -e "3. Review SSH configuration and disable password authentication"
echo -e "4. Consider installing intrusion detection tools"
echo -e "5. Run full rootkit and malware scans"
echo -e "6. Review user accounts and remove unnecessary privileges"
echo
echo -e "${BLUE}${BOLD}CyberShield Pro Security Suite${NC}"
echo -e "${BLUE}For more advanced security tools and features, check the full package documentation.${NC}" 