#!/usr/bin/env python3
"""
Automation Scripts Collection - Sample Script
This is a simple automation script that demonstrates file organization.
"""

import os
import shutil
import datetime
import argparse

def organize_files(directory, create_date_folders=False):
    """
    Organizes files in the specified directory by file type.
    
    Args:
        directory (str): Directory to organize
        create_date_folders (bool): If True, also create date-based folders
    """
    if not os.path.exists(directory):
        print(f"Directory {directory} does not exist!")
        return
    
    # Define file type categories
    categories = {
        "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"],
        "Documents": [".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt", ".xls", ".xlsx", ".ppt", ".pptx"],
        "Videos": [".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm"],
        "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"],
        "Archives": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
        "Code": [".py", ".js", ".html", ".css", ".java", ".cpp", ".c", ".php", ".rb", ".go", ".ts"]
    }
    
    # Create category folders if they don't exist
    for category in categories:
        category_path = os.path.join(directory, category)
        if not os.path.exists(category_path):
            os.makedirs(category_path)
    
    # Create "Other" folder for uncategorized files
    other_folder = os.path.join(directory, "Other")
    if not os.path.exists(other_folder):
        os.makedirs(other_folder)
    
    # Process all files in the directory
    for filename in os.listdir(directory):
        filepath = os.path.join(directory, filename)
        
        # Skip directories and already organized files
        if os.path.isdir(filepath) or filename.startswith('.'):
            continue
        
        # Get file extension
        file_ext = os.path.splitext(filename)[1].lower()
        
        # Find the appropriate category
        target_category = "Other"
        for category, extensions in categories.items():
            if file_ext in extensions:
                target_category = category
                break
        
        # Determine target directory
        target_dir = os.path.join(directory, target_category)
        
        # If date folders are enabled, create and use them
        if create_date_folders:
            file_modified = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
            date_folder = file_modified.strftime("%Y-%m")
            target_dir = os.path.join(target_dir, date_folder)
            
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
        
        # Move the file
        target_path = os.path.join(target_dir, filename)
        try:
            shutil.move(filepath, target_path)
            print(f"Moved: {filename} → {target_category}")
        except Exception as e:
            print(f"Error moving {filename}: {e}")

def main():
    parser = argparse.ArgumentParser(description="Organize files by type and optionally by date.")
    parser.add_argument("directory", help="Directory to organize")
    parser.add_argument("--date", action="store_true", help="Create date-based folders within categories")
    
    args = parser.parse_args()
    organize_files(args.directory, args.date)
    print("File organization complete!")

if __name__ == "__main__":
    main() 